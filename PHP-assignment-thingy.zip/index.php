<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body
  <?php
      for($vary = 1; $vary < 11; $vary++){
          if ($vary<5) {
            echo "<p>I was created with a small number</p>";}
          else{ echo "<p>I was created with a big number</p>";}
            if($vary%2==0) {
              echo "<h1 style=\"color:blue\">I was created with an even number</h1>";}
            else {  echo "<h1 style=\"color:red\">I was created with an odd number </h1>";}
          }
        ?>
    </body>
</html>